/*price range*/

 $('#sl2').slider();

	var RGBChange = function() {
	  $('#RGB').css('background', 'rgb('+r.getValue()+','+g.getValue()+','+b.getValue()+')')
	};	
		
/*scroll to top*/

$(document).ready(function(){
	$(function () {
		$.scrollUp({
	        scrollName: 'scrollUp', // Element ID
	        scrollDistance: 300, // Distance from top/bottom before showing element (px)
	        scrollFrom: 'top', // 'top' or 'bottom'
	        scrollSpeed: 300, // Speed back to top (ms)
	        easingType: 'linear', // Scroll to top easing (see http://easings.net/)
	        animation: 'fade', // Fade, slide, none
	        animationSpeed: 200, // Animation in speed (ms)
	        scrollTrigger: false, // Set a custom triggering element. Can be an HTML string or jQuery object
					//scrollTarget: false, // Set a custom target element for scrolling to the top
	        scrollText: '<i class="fa fa-angle-up"></i>', // Text for element, can contain HTML
	        scrollTitle: false, // Set a custom <a> title if required.
	        scrollImg: false, // Set true to use image
	        activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
	        zIndex: 2147483647 // Z-Index for the overlay
		});
	});
});
//--------------------

function submitFormLogout() 
{
	
	
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: false,
	     url : "/multi-vendor/Logout",

		
		success : function(data) {
			location.reload();

		},
		error : function(e) {
			location.reload();

		}
	});
}


// --------------------------
function validate()
{
	
		  var name = document.getElementById("xname").value;
		  var number = document.getElementById("number").value;
		  var email = document.getElementById("email").value;
		  var password = document.getElementById("password").value;
		  var adhar = document.getElementById("adhar").value;
		  var pan = document.getElementById("pan").value;
		  var address = document.getElementById("address").value;
		  
		  var numpattern = "[1-9]{1}[0-9]{2}-[0-9]{4}-[0-9]{3}";
		  
		  if (name.length > 3   &&  name.length < 50 ) 
		  {
			  $("#signupsubmit").removeAttr("disabled");
		  }
		  else 
		  {
			  $("#signupsubmit").prop("disabled","true");
			  
		 }
		  
		
}

function submitForm() 
{
	var name = document.getElementById("xname").value;
	  var number = document.getElementById("number").value;
	  var email = document.getElementById("email").value;
	  var password = document.getElementById("password").value;
	  var adhar = document.getElementById("adhar").value;
	  var pan = document.getElementById("pan").value;
	  var address = document.getElementById("address").value;
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: true,
	     url : "/multi-vendor/AdminSignUp",

		data : {
			name : name,
			number : number,
			email : email,
			password : password,
			adhar : adhar,
			pan : pan,
			address : address
		},
		success : function(data) {
			var output = JSON.parse(data);
			if (output.status === "success") {
				
				var x = jQuery("<div></div>").addClass("alert alert-success").append("<strong>Signup</strong> Successfull");
				$('#flash_success').html(x);
			} else {
				var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
				$('#flash_success').html(x);
			}
		},
		error : function(e) {
			
			var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
			$('#flash_success').html(x);
		}
	});
}



//-----------------------------

function validate1()
{
	
		
		  var email = document.getElementById("email").value;
		  var password = document.getElementById("password").value;
		  
		 
		  
		
}

function submitForm1() 
{
	
	var email = document.getElementById("email").value;
	var password = document.getElementById("password").value;
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: false,
	     url : "/multi-vendor/AdminLogin",

		data : {
			
			email : email,
			password : password
		},
		success : function(data) {
			
		
			var output = JSON.parse(data);
			location.reload();
			if (output.status === "success") {
				
				var x = jQuery("<div></div>").addClass("alert alert-success").append("<strong>Signup</strong> Successfull");
				$('#flash_success').html(x);
			} else {
				var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
				$('#flash_success').html(x);
			}
		},
		error : function(e) {
			location.reload();
			var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
			$('#flash_success').html(x);
		}
	});
}

// 2. Append somewhere



function loadUsers()
{
	$("#UserDataTable").empty();
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: false,
	     url : "/multi-vendor/GetUser",
		 success : function(data) 
		 {
			
			var table=jQuery("<table></table>").addClass("table");
			
			var theading=jQuery("<thead><tr></tr></thead>").append("<th>User ID</th><th>Name</th><th>Mobile Number</th><th>Email</th><th>Pin Code</th><th>Registration Date&Time</th>");
			table.append(theading);
			for (var d in data)
				{
				
				var tr=jQuery("<tbody><tr></tr></tbody>");
				var td1=jQuery("<td></td>").append(data[d].user_id);
				var td2=jQuery("<td></td>").append(data[d].user_name);
				var td3=jQuery("<td></td>").append(data[d].user_MobileNo);
				var td4=jQuery("<td></td>").append(data[d].user_Email);
				var td5=jQuery("<td></td>").append(data[d].user_pincode);
				var td6=jQuery("<td></td>").append(data[d].user_registration_date);
				var td7=jQuery("<td></td>");
				if(data[d].status == "0")
				{
					var da=data[d].user_id;
					var button = jQuery("<button></button>").addClass("btn btn-success").html("Block");
					 button.bind("click",da,function(e){
						
						 jQuery.ajax({
							 type : "POST",
							 dataType: "json",
							 async: true,
						    	url : "/multi-vendor/UpdateUserStatus",

							data : {
								user_id : e.data,
								status : "1",
								
							},
							success : function(data) {
								//var output = JSON.parse(data);
								loadUsers();
								
							},
							
						});
					 });
					 td7.append(button);
				}else
				{
					var da=data[d].user_id;
					var button = jQuery("<button></button>").addClass("btn btn-success").html("Unblock");
					 button.bind("click",da,function(e){
						
						 jQuery.ajax({
							 type : "POST",
							 dataType: "json",
							 async: true,
						    	url : "/multi-vendor/UpdateUserStatus",

							data : {
								user_id: e.data,
								status : "0",
								
							},
							success : function(data) {
								//var output = JSON.parse(data);
								loadUsers();
								
							},
							
						});
					 });
					 td7.append(button);
				}
				
				
				
				tr.append(td1).append(td2).append(td3).append(td4).append(td5).append(td6).append(td7);
				table.append(tr);
				}
				
			$("#UserDataTable").append(table);
		 },
		error : function(e) 
		{
			var x = jQuery("<p></p>").addClass("text-danger").append("error in form");
			$('#flash_success').html(x);
		}
	});
}

function loadSellers()
{
	$("#SellerDataTable").empty();
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: false,
	     url : "/multi-vendor/GetSeller",
		 success : function(data) 
		 {
			
			var table=jQuery("<table></table>").addClass("table");
			
			var theading=jQuery("<thead><tr></tr></thead>").append("<th>Seller ID</th><th>Name</th><th>Mobile Number</th><th>Email</th><th>Account No</th<th>Address</th><th>Registration Date&Time</th>");
			table.append(theading);
			for (var d in data)
				{
				
				var tr=jQuery("<tbody><tr></tr></tbody>");
				var td1=jQuery("<td></td>").append(data[d].seller_id);
				var td2=jQuery("<td></td>").append(data[d].seller_name);
				var td3=jQuery("<td></td>").append(data[d].seller_MobileNo);
				var td4=jQuery("<td></td>").append(data[d]. seller_Email);/*
				var td5=jQuery("<td></td>").append(data[d].seller_AadharCard);
				var td6=jQuery("<td></td>").append(data[d].seller_pancard);
				var td7=jQuery("<td></td>").append(data[d].seller_GSTIN_No);*/
				var td8=jQuery("<td></td>").append(data[d].account_number);
			//	var td9=jQuery("<td></td>").append(data[d].ifsc_code);
				var td10=jQuery("<td></td>").append(data[d].seller_Address);
				var td11=jQuery("<td></td>").append(data[d].seller_registraiondate);
				var td12=jQuery("<td></td>");
				if(data[d].status == "0")
				{
					var da=data[d].seller_id;
					var button = jQuery("<button></button>").addClass("btn btn-success").html("Block");
					 button.bind("click",da,function(e){
						
						 jQuery.ajax({
							 type : "POST",
							 dataType: "json",
							 async: true,
						    	url : "/multi-vendor/UpdateSellerStatus",

							data : {
								seller_id : e.data,
								status : "1",
								
							},
							success : function(data) {
								//var output = JSON.parse(data);
								loadSellers();
								
								
							},
							
						});
					 });
					 td12.append(button);
				}else
				{
					var da=data[d].seller_id;
					var button = jQuery("<button></button>").addClass("btn btn-success").html("Unblock");
					 button.bind("click",da,function(e){
						
						 jQuery.ajax({
							 type : "POST",
							 dataType: "json",
							 async: true,
						    	url : "/multi-vendor/UpdateSellerStatus",

							data : {
								seller_id : e.data,
								status : "0",
								
							},
							success : function(data) {
								//var output = JSON.parse(data);
								loadSellers();
								
							},
							
						});
					 });
					 td12.append(button);
				}
				
				
				
				tr.append(td1).append(td2).append(td3).append(td4).append(td8).append(td10).append(td11).append(td12);
				table.append(tr);
				}
				
			$("#SellerDataTable").append(table);
		 },
		error : function(e) 
		{
			var x = jQuery("<p></p>").addClass("text-danger").append("error in form");
			$('#flash_success').html(x);
		}
	});
}


function loadLogistic()
{
	$("#LogisticDataTable").empty();
	jQuery.ajax({
		
		 type : "POST",
		 dataType: "json",
		 async: false,
	     url : "/multi-vendor/GetLogistic",
		 success : function(data) 
		 {
			
			var table=jQuery("<table></table>").addClass("table");
			
			var theading=jQuery("<thead><tr></tr></thead>").append("<th>Logistic ID</th><th>Name</th><th>Mobile Number</th><th>Email</th><th>Adhar Number</th><th>PAN Number</th><th>Address</th><th>Registration Date&Time</th>");
			table.append(theading);
			for (var d in data)
				{
				
				var tr=jQuery("<tbody><tr></tr></tbody>");
				var td1=jQuery("<td></td>").append(data[d].logistic_id);
				var td2=jQuery("<td></td>").append(data[d].name);
				var td3=jQuery("<td></td>").append(data[d].mobile_no);
				var td4=jQuery("<td></td>").append(data[d].email);
				var td5=jQuery("<td></td>").append(data[d].aadhar_card);
				var td6=jQuery("<td></td>").append(data[d].pan_card);
				var td7=jQuery("<td></td>").append(data[d].address);
				var td8=jQuery("<td></td>").append(data[d].registration_date);
				var td9=jQuery("<td></td>");
				if(data[d].status == "0")
				{
					var da=data[d].logistic_id;
					var button = jQuery("<button></button>").addClass("btn btn-success").html("Block");
					 button.bind("click",da,function(e){
						
						 jQuery.ajax({
							 type : "POST",
							 dataType: "json",
							 async: true,
						    	url : "/multi-vendor/UpdateLogisticStatus",

							data : {
								logistic_id : e.data,
								status : "1",
								
							},
							success : function(data) {
								//var output = JSON.parse(data);
								loadLogistic();
								
							},
							
						});
					 });
					 td9.append(button);
				}else
				{
					var da=data[d].logistic_id;
					var button = jQuery("<button></button>").addClass("btn btn-success").html("Unblock");
					 button.bind("click",da,function(e){
						
						 jQuery.ajax({
							 type : "POST",
							 dataType: "json",
							 async: true,
						    	url : "/multi-vendor/UpdateLogisticStatus",

							data : {
								logistic_id : e.data,
								status : "0",
								
							},
							success : function(data) {
								//var output = JSON.parse(data);
								loadLogistic();
								
								
							},
							
						});
					 });
					 td9.append(button);
				}
				
				
				
				tr.append(td1).append(td2).append(td3).append(td4).append(td5).append(td6).append(td7).append(td8).append(td9);
				table.append(tr);
				}
				
			$("#LogisticDataTable").append(table);
		 },
		error : function(e) 
		{
			var x = jQuery("<p></p>").addClass("text-danger").append("error in form");
			$('#flash_success').html(x);
		}
	});

}

function loadProduct()
{
	$("#ProductDataTable").empty();
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: false,
	     url : "/multi-vendor/GetProduct",
		 success : function(data) 
		 {
			
			var table=jQuery("<table></table>").addClass("table");
			
			var theading=jQuery("<thead><tr></tr></thead>").append("<th>Product ID</th><th>Name</th>");
			table.append(theading);
			for (var d in data)
				{
				
				var tr=jQuery("<tbody><tr></tr></tbody>");
				var td1=jQuery("<td></td>").append(data[d].product_id);
				var td2=jQuery("<td></td>").append(data[d].product_name);
				var td3=jQuery("<td></td>");
				if(data[d].status == "0")
				{
					var da=data[d].product_id;
					var button = jQuery("<button></button>").addClass("btn btn-success").html("Block");
					 button.bind("click",da,function(e){
						
						 jQuery.ajax({
							 type : "POST",
							 dataType: "json",
							 async: true,
						    	url : "/multi-vendor/UpdateProductStatus",

							data : {
								admin_id : e.data,
								status : "1",
								
							},
							success : function(data) {
								//var output = JSON.parse(data);
								loadProduct();
								
							},
							
						});
					 });
					 td3.append(button);
				}else
				{
					var da=data[d].product_id;
					var button = jQuery("<button></button>").addClass("btn btn-success").html("Unblock");
					 button.bind("click",da,function(e){
						
						 jQuery.ajax({
							 type : "POST",
							 dataType: "json",
							 async: true,
						    	url : "/multi-vendor/UpdateProductSatus",

							data : {
								admin_id : e.data,
								status : "0",
								
							},
							success : function(data) {
								//var output = JSON.parse(data);
								loadProduct();
								
							},
							
						});
					 });
					 td3.append(button);
				}
				
				
				
				tr.append(td1).append(td2).append(td3);
				table.append(tr);
				}
				
			$("#ProductDataTable").append(table);
		 },
		error : function(e) 
		{
			var x = jQuery("<p></p>").addClass("text-danger").append("error in form");
			$('#flash_success').html(x);
		}
	});
}